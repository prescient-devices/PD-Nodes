This is a test of a binary file
